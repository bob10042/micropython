on power up display 
Gen3	
Cycles
On comm test: add AutoCAF/AutoSIR and optionaly TH line
 